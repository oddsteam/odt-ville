ODT Ville — map starter kit
===========================

You need Tiled (free): https://www.mapeditor.org/

1. Open starter.tmj in Tiled. Every tileset the server has is already loaded
   in the Tilesets panel on the right.
2. Paint your map. Use the "ground" layer for terrain and "decor" for things
   that draw on top. You can add more layers — later layers draw over earlier
   ones.
3. Resize the map if you want: Map > Resize Map. Keep the tile size at 32x32.
4. File > Save As... > name it whatever you like, keeping the .tmj extension.
   Do NOT use "Export As".
5. Go to /admin/maps/new in ODT Ville, pick your .tmj under "Import Tiled
   JSON", fill in a slug and title, and Save.

Rules the importer enforces (it will tell you which one you broke):

  - Tile size must be 32x32, on the map and on every tileset.
  - Tilesets must stay EMBEDDED. Never click "Export Tileset As" or detach a
    tileset — if you do, the map references an external .tsx file the server
    can't read.
  - Don't add your own tileset images. The server can only draw the tilesets
    in this kit. If you need new art, ask a developer to add the PNG to the
    server first.
  - Tileset margin and spacing must stay 0.

Object layers (including collisions) are ignored on import — a new map starts
fully walkable. You paint collision and place props in the app after saving.
